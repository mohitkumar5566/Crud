import { SliceTextPipe } from './slice-text.pipe';

describe('SliceTextPipe', () => {
  it('create an instance', () => {
    const pipe = new SliceTextPipe();
    expect(pipe).toBeTruthy();
  });
});
