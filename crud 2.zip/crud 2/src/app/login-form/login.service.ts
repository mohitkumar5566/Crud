import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  logout() {
    throw new Error('Method not implemented.');
  }
  // Define the API URL for login
  private readonly url = environment.baseUrl + "Login/";

  constructor(private http: HttpClient) {}

  // Method to log in the user
  loginUser(credentials: { email: string, password: string }): Observable<any> {
    return this.http.post(this.url + "login", credentials);
  }

  // Optional: Method to get all users (if needed)
  getAllUsers(): Observable<any> {
    return this.http.get(this.url + "getdata"); // Adjusted endpoint for getting users if needed
  }
}
