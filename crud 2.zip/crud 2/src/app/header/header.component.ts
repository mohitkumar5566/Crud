import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  isLoggedIn: boolean = false; 
  userEmail: string | null = null;
  userDetail: any;
  isDarkMode: boolean = false;

  
  constructor(private ck:CookieService, private router:Router){
      this.isLoggedIn = this.ck.check("userdetail"); // User is not logged in
  }

  logoutbtn(){
            this.ck.delete("userdetail")
            this.router.navigate(['login']); // Redirect to HomeComponent
  }

  loginbtn() {
    // Logic for logging in
    this.router.navigate(['login']); // Redirect to the login page

  }


  ngOnInit() {

    this.userDetail = JSON.parse(this.ck.get("userdetail")); 
    // console.log('detail',this.userDetail);
    
  }
}

