import { Routes } from '@angular/router';
import { UserComponent } from './user/user.component';
import { ProfileComponent } from './profile/profile.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { SignupFormComponent } from './signup-form/signup-form.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { DarkComponent } from './dark/dark.component';

export const routes: Routes = [
    {path: 'user', component:UserComponent},
    {path: 'profile', component:ProfileComponent},
    {path: 'header', component:HeaderComponent},
    {path: '', component:HomeComponent},
    {path: 'signup', component:SignupFormComponent},
    {path: 'login', component:LoginFormComponent},
    {path: 'dark', component:DarkComponent},
];
