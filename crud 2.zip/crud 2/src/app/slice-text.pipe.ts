import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sliceText',
  standalone: true
})
export class SliceTextPipe implements PipeTransform {

  transform(value: any, limit:any): unknown {
    return value.length>limit?value.substring(0,limit)+"...Read More":value;
  }

}