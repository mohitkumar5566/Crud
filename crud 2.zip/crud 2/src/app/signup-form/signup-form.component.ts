import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SignupService } from './signup.service'; // Import the service
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-signup-form',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.css']
})
export class SignupFormComponent {
  userForm: FormGroup;
  user: any;

  constructor(private fb: FormBuilder, private service: SignupService) {  // Inject the service
    this.userForm = this.fb.group({
      yourName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      repeatPassword: ['', Validators.required]
    }, { validator: this.passwordMatchValidator }); // Add custom validation for matching passwords
  }

  // Custom validator to check if passwords match
  passwordMatchValidator(group: FormGroup) {
    return group.get('password')?.value === group.get('repeatPassword')?.value 
      ? null : { 'mismatch': true };
  }

  // Method to handle form submission
  onSubmit() {
    if (this.userForm.valid) {
      const formData = this.userForm.value;
      this.service.addUser(formData).subscribe(
        response => {
          console.log('User added successfully', response);
        },
        error => {
          console.log('Error adding user', error);
        }
      );
    } else {
      console.log('Form is invalid');
    }
  }

  // Method to get all users from the API
  getAllUsers() {
    this.service.getAllUsers().subscribe(
      (data: any) => {
        console.log("Users", data);
        this.user = data.result;
      },
      error => {
        console.log("Error fetching users", error);
      }
    );
  }
}
