import { Component } from '@angular/core';

import { UserComponent } from "../user/user.component";
import { ProfileComponent } from "../profile/profile.component";
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [UserComponent, ProfileComponent],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'] // Corrected styleUrl to styleUrls
})
export class HomeComponent {

  constructor(private ck:CookieService, private router:Router){

  }

  ngOnInit() {

    if(! this.ck.get("userdetail")){
      this.router.navigate(['login']); // Redirect to HomeComponent
    }
  }
}
