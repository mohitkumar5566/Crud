import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginService } from './login.service'; // Import your login service
import { Router } from '@angular/router'; // Import Router
import { ReactiveFormsModule } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-login-form',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent {
  loginForm: FormGroup;
  cookieService: any;
  cookieValue: any;

  constructor(private fb: FormBuilder, private service: LoginService, private router: Router, private cookie: CookieService) { 

    
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }
  
  ngOnInit():void {
      if(this.cookie.get("userdetail")){
        this.router.navigate(['']); // Redirect to HomeComponent
      }
  }


  onSubmit() {
    if (this.loginForm.valid) {

      const formData = this.loginForm.value;
      this.service.loginUser(formData).subscribe(
        response => {
          console.log('Login successful', response);

          if(response.message== "Login successful"){
            this.router.navigate(['']); // Redirect to HomeComponent
            this.cookie.set("userdetail", JSON.stringify(response.result), { expires: 1 }); 

            
          } else{
            alert(response.message)
          }
      
          
        },
        error => {
          console.log('Error logging in', error);
        }
      );
    } else {
      console.log('Form is invalid');
    }
  }
}
