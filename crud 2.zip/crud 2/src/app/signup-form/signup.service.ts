import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SignupService {

  readonly url = environment.baseUrl;

  constructor(private http: HttpClient) { }

  // Method to add a new user
  addUser(user: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.post(this.url + "Signup/postdata", user, { headers });
  }

  // Method to get all users
  getAllUsers(): Observable<any> {
    return this.http.get(this.url + "Signup/getdata");
  }
}
