import { Component } from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-dark',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './dark.component.html',
  styleUrl: './dark.component.css'
})
export class DarkComponent {
  userForm: any;
  service: any;
  
  constructor( private fb:FormBuilder){
    this.userForm = this.fb.group({

      Id:[0],
      Name:[""],
      Email:[""],
      Mobile:[""],
      Age:[""]
      
    })
  }

  SubmitForm(){

    console.log(this.userForm.value);
    this.userForm.reset(); 
    
  }

  }
