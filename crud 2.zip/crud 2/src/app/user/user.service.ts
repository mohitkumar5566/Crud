import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  readonly url = environment.baseUrl;

  constructor(private http: HttpClient) {}

  // Method for adding a user, using POST instead of GET
  AddUser(user: any): Observable<any> {

    // Define headers if necessary
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    // Use POST method to add the user, passing the user data in the request body
    return this.http.post(this.url + "Ecomm/postdata", user);
  }

 GetAllUsers(): Observable<any> {
  return this.http.get(this.url + "Ecomm/getdata");
}

DeleteUserById(id:any): Observable<any> {
  return this.http.delete(this.url + "Ecomm/deletedata/"+ id);
}
}
