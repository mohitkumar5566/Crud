import { Component, OnInit } from '@angular/core';
import { UserService } from '../user/user.service';
import { CommonModule } from '@angular/common';
import { SliceTextPipe } from '../slice-text.pipe';

declare var $:any;

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, SliceTextPipe],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  
  user: any; // Define a proper type if possible
  service: UserService; // Service should be typed properly
  todayDate = new Date();
  des ="Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facere fuga, at tempora dolorem accusamus ipsam. Ipsam et quos nobis tempore doloremque perferendis rem. Veniam soluta molestias cumque ipsa ducimus perspiciatis laudantium unde, ullam inventore pariatur expedita veritatis fugiat omnis architecto error est officiis doloribus et eveniet! Magnam facere possimus illum iste expedita fuga rerum nam repudiandae assumenda ut, harum saepe quia alias omnis voluptas. Maiores dolorem consequatur doloremque voluptatibus laborum atque magnam alias corrupti, dicta inventore ut iusto hic quas consequuntur dignissimos aut nulla libero ad soluta aperiam! Ab repellendus non autem sit nostrum animi dolore labore, nulla expedita ea?";

  constructor(private userService: UserService) {
    this.service = userService; // Initialize the service
  }

  ngOnInit(): void {
    this.GetAllUsers();
  }

  GetAllUsers(): void {
    this.service.GetAllUsers().subscribe(data => {
      console.log("user", data);
      this.user = data.result;

    });
  }

  DeleteUserById(id: any): void {
    this.service.DeleteUserById(id).subscribe(() => {
      alert("User Deleted");
      this.GetAllUsers();
    });

  }
}
