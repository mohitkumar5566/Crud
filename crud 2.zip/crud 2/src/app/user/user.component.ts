import { Component } from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { UserService } from './user.service';

declare var $:any;

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})

export class UserComponent {

  userForm:any;
  user: any;
itme: any;

  constructor(public fb:FormBuilder, private service:UserService){
    this.userForm = this.fb.group(
      {
        id:[0],
        name:[""],
        email:[""],
        mobile:[],
        age:[]
      }
    )
  }

  SubmitForm(){
    // console.log(this.userForm.value);
    this.userForm.patchValue({id:this.userForm.value.id==null?0:this.userForm.value.id})
    this.service.AddUser(this.userForm.value).subscribe(data =>{
      // console.log(data);
      this.userForm.reset(); 
      $("#profile-tab").addClass('active')  
      $("#home-tab").removeClass('active')
      $("#profile-tab-pane").addClass('active show')
      $("#home-tab-pane").removeClass('active show')
      $("#profile-tab-pane").attr('aria-selected="false"')
      this.GetAllUsers();
})};

  GetAllUsers(){

    this.service.GetAllUsers().subscribe(data =>{
      console.log("dark", data)
      this.user = data.result;
      
    })};
 


}
